# SMPM Frontend (Enhanced)

Instalação:
cd frontend
npm install
npm run dev

Abra http://localhost:5173
Usuário admin padrão será criado automaticamente pelo backend: admin / admin123
