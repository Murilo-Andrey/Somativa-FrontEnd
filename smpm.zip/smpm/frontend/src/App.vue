<template>
  <div :class="darkMode ? 'dark' : ''">
    <header class="header text-white p-4">
      <div class="max-w-6xl mx-auto flex items-center justify-between">
        <h1 class="text-2xl font-bold">SMPM — Manutenção</h1>
        <nav class="flex items-center gap-4">
          <router-link to="/" class="text-white">Dashboard</router-link>
          <router-link to="/maintenances" class="text-white">Manutenções</router-link>
          <router-link to="/calendar" class="text-white">Calendário</router-link>
          <button @click="toggleDark" class="ml-4 bg-white text-black px-3 py-1 rounded">{{ darkMode ? 'Claro' : 'Escuro' }}</button>
          <router-link to="/login" v-if="!isAuthenticated" class="ml-4 text-white">Login</router-link>
          <button v-if="isAuthenticated" @click="logout" class="ml-4 text-white">Sair</button>
        </nav>
      </div>
    </header>

    <main class="max-w-6xl mx-auto p-6">
      <router-view />
    </main>
  </div>
</template>

<script>
import { ref, computed } from 'vue'
import { useRouter } from 'vue-router'

export default {
  setup() {
    const darkMode = ref(localStorage.getItem('dark') === '1');
    const toggleDark = () => { darkMode.value = !darkMode.value; localStorage.setItem('dark', darkMode.value ? '1' : '0'); };
    const router = useRouter();
    const isAuthenticated = computed(() => !!localStorage.getItem('token'));
    const logout = () => { localStorage.removeItem('token'); localStorage.removeItem('user'); router.push('/login'); };
    return { darkMode, toggleDark, isAuthenticated, logout };
  }
}
</script>

<style>
/* minimal styles; real project may use Tailwind */
.header { background: linear-gradient(90deg,#17a2b8,#6f42c1); }
.card { border-radius: 8px; box-shadow: 0 6px 18px rgba(31,45,61,0.06); padding: 16px; }
.btn { padding: 8px 12px; border-radius: 6px; }
</style>
