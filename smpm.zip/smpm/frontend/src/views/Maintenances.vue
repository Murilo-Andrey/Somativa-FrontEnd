<template>
  <div>
    <div class="flex gap-4 mb-4">
      <button @click="showForm = true" class="btn bg-green-600 text-white">Nova Manutenção</button>
    </div>

    <MaintenanceForm v-if="showForm" :machines="machines" @save="create" @cancel="showForm = false"/>
    <MaintenanceTable :maintenances="maintenances" @filter="fetchWithFilters" @delete="remove"/>
  </div>
</template>

<script>
import { useMainStore } from '../store'
import { ref, onMounted } from 'vue'
import MaintenanceTable from '../components/MaintenanceTable.vue'
import MaintenanceForm from '../components/MaintenanceForm.vue'
import api from '../services/api'

export default {
  components: { MaintenanceTable, MaintenanceForm },
  setup() {
    const store = useMainStore();
    const showForm = ref(false);
    onMounted(async () => { await store.fetchMachines(); await store.fetchMaintenances(); });
    const create = async (data) => { await api.createMaintenance(data); await store.fetchMaintenances(); showForm.value = false; };
    const fetchWithFilters = async (params) => { await store.fetchMaintenances(params); };
    const remove = async (id) => { if (!confirm('Confirma remoção?')) return; await api.deleteMaintenance(id); await store.fetchMaintenances(); };
    return { machines: store.machines, maintenances: store.maintenances, showForm, create, fetchWithFilters, remove };
  }
}
</script>
