<template>
  <div>
    <h2 class="text-xl font-semibold mb-4">Calendário de Manutenções</h2>
    <FullCalendar :plugins="calendarPlugins" :events="events" initialView="dayGridMonth" />
  </div>
</template>

<script>
import FullCalendar from '@fullcalendar/vue3'
import dayGridPlugin from '@fullcalendar/daygrid'
import api from '../services/api'
import { ref, onMounted } from 'vue'

export default {
  components: { FullCalendar },
  setup() {
    const events = ref([]);
    const calendarPlugins = [ dayGridPlugin ];
    onMounted(async () => {
      const res = await api.listMaintenances();
      events.value = res.data.map(m => ({
        id: m.id,
        title: `${m.machine_name}: ${m.title}`,
        start: m.scheduled_at
      }));
    });
    return { events, calendarPlugins };
  }
}
</script>

<style>
/* FullCalendar default styles will be included by the npm package when built */
</style>
