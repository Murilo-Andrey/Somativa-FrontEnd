<template>
  <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <KpiCard title="Máquinas" :value="kpis.totalMachines"/>
    <KpiCard title="Programadas" :value="kpis.scheduled"/>
    <KpiCard title="Realizadas" :value="kpis.performed"/>
    <div class="md:col-span-3 mt-4">
      <h2 class="text-xl font-semibold mb-2">Últimas manutenções</h2>
      <MaintenanceTable :maintenances="maintenances" @filter="onFilter"/>
    </div>
  </div>
</template>

<script>
import { useMainStore } from '../store'
import { onMounted } from 'vue'
import KpiCard from '../components/KpiCard.vue'
import MaintenanceTable from '../components/MaintenanceTable.vue'

export default {
  components: { KpiCard, MaintenanceTable },
  setup() {
    const store = useMainStore();
    onMounted(async () => { await store.fetchMachines(); await store.fetchMaintenances(); });
    const onFilter = async (params) => { await store.fetchMaintenances(params); };
    return { kpis: store.kpis, maintenances: store.maintenances, onFilter };
  }
}
</script>
