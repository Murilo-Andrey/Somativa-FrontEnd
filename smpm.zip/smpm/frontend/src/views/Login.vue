<template>
  <div class="max-w-md mx-auto">
    <div class="card p-6 bg-white">
      <h2 class="text-xl font-semibold mb-4">Login</h2>
      <form @submit.prevent="submit">
        <label class="block mb-2"><div>Usuário</div><input v-model="form.username" class="w-full border p-2 rounded"/></label>
        <label class="block mb-2"><div>Senha</div><input type="password" v-model="form.password" class="w-full border p-2 rounded"/></label>
        <div class="flex gap-2">
          <button class="btn bg-accent text-white">Entrar</button>
        </div>
      </form>
      <div v-if="error" class="text-red-600 mt-2">{{ error }}</div>
    </div>
  </div>
</template>

<script>
import api from '../services/api'
import { useRouter } from 'vue-router'
import { ref } from 'vue'

export default {
  setup() {
    const form = ref({ username: '', password: '' });
    const error = ref('');
    const router = useRouter();
    const submit = async () => {
      try {
        const res = await api.login(form.value);
        localStorage.setItem('token', res.data.token);
        localStorage.setItem('user', JSON.stringify(res.data.user));
        router.push('/');
      } catch (e) {
        error.value = e.response?.data?.error || 'Erro ao logar';
      }
    };
    return { form, submit, error };
  }
}
</script>
