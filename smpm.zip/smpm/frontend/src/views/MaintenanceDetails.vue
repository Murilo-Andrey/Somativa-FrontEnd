<template>
  <div>
    <div v-if="item" class="card p-4 bg-white">
      <h2 class="text-xl font-semibold">{{ item.title }}</h2>
      <p class="text-sm text-gray-500">Máquina: {{ item.machine_name }}</p>
      <p class="mt-2">{{ item.description }}</p>
      <p class="mt-2">Agendada: {{ item.scheduled_at }}</p>
      <p class="mt-2">Status: {{ item.status }}</p>
    </div>
    <div v-else>Carregando...</div>
  </div>
</template>

<script>
import api from '../services/api'
import { ref, onMounted } from 'vue'

export default {
  props: ['id'],
  setup(props) {
    const item = ref(null);
    onMounted(async () => {
      const id = props.id || (window.location.pathname.split('/').pop());
      const res = await api.getMaintenance(id);
      item.value = res.data;
    });
    return { item };
  }
}
</script>
