import { createRouter, createWebHistory } from 'vue-router'
import Dashboard from '../views/Dashboard.vue'
import Maintenances from '../views/Maintenances.vue'
import MaintenanceDetails from '../views/MaintenanceDetails.vue'
import Login from '../views/Login.vue'
import CalendarView from '../views/Calendar.vue'

const routes = [
  { path: '/', name: 'Dashboard', component: Dashboard },
  { path: '/maintenances', name: 'Maintenances', component: Maintenances },
  { path: '/maintenances/:id', name: 'MaintenanceDetails', component: MaintenanceDetails, props: true },
  { path: '/login', name: 'Login', component: Login },
  { path: '/calendar', name: 'Calendar', component: CalendarView }
]

const router = createRouter({ history: createWebHistory(), routes })
export default router
