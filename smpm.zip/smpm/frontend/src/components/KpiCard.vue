<template>
  <div class="card p-4 bg-white">
    <div class="text-sm text-gray-500">{{ title }}</div>
    <div class="text-3xl font-bold mt-1">{{ value }}</div>
    <div v-if="subtitle" class="text-xs text-gray-400 mt-1">{{ subtitle }}</div>
  </div>
</template>
<script>
export default { props: { title: String, value: [String, Number], subtitle: String } }
</script>
