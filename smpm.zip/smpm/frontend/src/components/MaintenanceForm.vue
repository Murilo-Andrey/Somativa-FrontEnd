<template>
  <div class="p-6 bg-white dark:bg-gray-800 rounded-xl shadow-md">
    <h2 class="text-xl font-semibold mb-4 dark:text-white">Nova Manutenção</h2>

    <form @submit.prevent="submit">
      <label class="block mb-2 dark:text-gray-200">Máquina</label>
      <select v-model="form.machine_id" required class="w-full p-2 border rounded mb-4 dark:bg-gray-700 dark:text-white dark:border-gray-600">
        <option disabled value="">Selecione uma máquina</option>
        <option v-for="m in machines" :value="m.id" :key="m.id">{{ m.name }}</option>
      </select>

      <label class="block mb-2 dark:text-gray-200">Título</label>
      <input v-model="form.title" required type="text" class="w-full p-2 border rounded mb-4 dark:bg-gray-700 dark:text-white dark:border-gray-600"/>

      <label class="block mb-2 dark:text-gray-200">Descrição</label>
      <textarea v-model="form.description" rows="3" required class="w-full p-2 border rounded mb-4 dark:bg-gray-700 dark:text-white dark:border-gray-600"></textarea>

      <label class="block mb-2 dark:text-gray-200">Data programada</label>
      <input v-model="form.scheduled_date" required type="datetime-local" class="w-full p-2 border rounded mb-4 dark:bg-gray-700 dark:text-white dark:border-gray-600"/>

      <div class="flex justify-between mt-6">
        <button type="button" @click="$emit('cancel')" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400 dark:bg-gray-700 dark:text-white dark:hover:bg-gray-600">
          Cancelar
        </button>

        <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
          Confirmar
        </button>
      </div>
    </form>
  </div>
</template>

<script>
import api from "../services/api";

export default {
  props: { machines: Array },

  data() {
    return {
      form: {
        machine_id: "",
        title: "",
        description: "",
        scheduled_date: "",
      },
    };
  },

  methods: {
    async submit() {
      await api.createMaintenance(this.form);
      this.$emit("created");
      this.$emit("cancel");
    },
  },
};
</script>
