import axios from 'axios';
const API = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:4000/api', timeout: 10000 });

// attach token
API.interceptors.request.use(cfg => {
  const token = localStorage.getItem('token');
  if (token) cfg.headers.Authorization = 'Bearer ' + token;
  return cfg;
});

export default {
  // auth
  login(data) { return API.post('/auth/login', data); },

  // machines
  listMachines(params) { return API.get('/machines', { params }); },
  getMachine(id) { return API.get(`/machines/${id}`); },
  createMachine(data) { return API.post('/machines', data); },
  updateMachine(id, data) { return API.put(`/machines/${id}`, data); },

  // maintenances
  listMaintenances(params) { return API.get('/maintenances', { params }); },
  getMaintenance(id) { return API.get(`/maintenances/${id}`); },
  createMaintenance(data) { return API.post('/maintenances', data); },
  updateMaintenance(id, data) { return API.put(`/maintenances/${id}`, data); },
  deleteMaintenance(id) { return API.delete(`/maintenances/${id}`); }
};
