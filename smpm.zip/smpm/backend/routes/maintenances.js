const express = require('express');
const router = express.Router();
const controller = require('../controllers/maintController');
const { ensureAuth } = require('../utils/auth');

router.get('/', controller.list);
router.get('/:id', controller.getById);
router.post('/', ensureAuth, controller.create);
router.put('/:id', ensureAuth, controller.update);
router.delete('/:id', ensureAuth, controller.remove);

module.exports = router;
