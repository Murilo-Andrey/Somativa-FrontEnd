const db = require('../db');

exports.list = (req, res) => {
  const { machine_id, status, from, to, q } = req.query;
  let sql = 'SELECT m.*, machines.name as machine_name FROM maintenances m JOIN machines ON m.machine_id = machines.id WHERE 1=1';
  const params = [];

  if (machine_id) { sql += ' AND m.machine_id = ?'; params.push(machine_id); }
  if (status) { sql += ' AND m.status = ?'; params.push(status); }
  if (from) { sql += ' AND datetime(m.scheduled_at) >= datetime(?)'; params.push(from); }
  if (to) { sql += ' AND datetime(m.scheduled_at) <= datetime(?)'; params.push(to); }
  if (q) { sql += ' AND (m.title LIKE ? OR m.description LIKE ?)'; params.push(`%${q}%`, `%${q}%`); }

  sql += ' ORDER BY m.scheduled_at DESC';

  db.all(sql, params, (err, rows) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(rows);
  });
};

exports.getById = (req, res) => {
  db.get('SELECT m.*, machines.name as machine_name FROM maintenances m JOIN machines ON m.machine_id = machines.id WHERE m.id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ error: err.message });
    res.json(row);
  });
};

exports.create = (req, res) => {
  const { machine_id, title, description, scheduled_at } = req.body;
  const stmt = 'INSERT INTO maintenances (machine_id, title, description, scheduled_at, status) VALUES (?, ?, ?, ?, ?)';
  db.run(stmt, [machine_id, title, description, scheduled_at, 'programada'], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    db.get('SELECT m.*, machines.name as machine_name FROM maintenances m JOIN machines ON m.machine_id = machines.id WHERE m.id = ?', [this.lastID], (e, row) => {
      if (e) return res.status(500).json({ error: e.message });
      res.status(201).json(row);
    });
  });
};

exports.update = (req, res) => {
  const { machine_id, title, description, scheduled_at, status } = req.body;
  db.run('UPDATE maintenances SET machine_id = ?, title = ?, description = ?, scheduled_at = ?, status = ? WHERE id = ?', [machine_id, title, description, scheduled_at, status, req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    db.get('SELECT * FROM maintenances WHERE id = ?', [req.params.id], (e,row) => {
      if (e) return res.status(500).json({ error: e.message });
      res.json(row);
    });
  });
};

exports.remove = (req, res) => {
  db.run('DELETE FROM maintenances WHERE id = ?', [req.params.id], function(err) {
    if (err) return res.status(500).json({ error: err.message });
    res.status(204).send();
  });
};
