require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const db = require('./db');
const fs = require('fs');
const path = require('path');

const authRoutes = require('./routes/auth');
const machinesRoutes = require('./routes/machines');
const maintRoutes = require('./routes/maintenances');
const authController = require('./controllers/authController');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// seed admin if missing after migrations
authController.seedAdminIfMissing(db);

app.use('/api/auth', authRoutes);
app.use('/api/machines', machinesRoutes);
app.use('/api/maintenances', maintRoutes);

// health
app.get('/api/health', (req,res) => res.json({ status: 'ok', time: new Date() }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`API rodando na porta ${PORT}`);
});
